require("graph") || stop("unable to load graph package")
graph:::.test()

